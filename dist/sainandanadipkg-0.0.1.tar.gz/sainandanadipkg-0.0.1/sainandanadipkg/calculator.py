"""
Demo package calculator application

Author : Sainandan
Date   : 31 Oct, 23
"""

def add(a, b):
    """
    Adds two numbers and returns the result
    """
    return a+b

def sub(a, b):
    """
    Subtracts two numbers and returns the result
    """
    return a-b

def multiply(a, b):
    """
    Multiplies two numbers and returns the result
    """
    return a*b

def divide(a, b):
    """
    Divides two numbers and returns the result
    """
    return a/b
